# 蓝桥杯单片机驱动库（STC15F2K60S2）

  本项目面向参加蓝桥杯单片机赛道（C51/Keil）考生，提供一套结构清晰、可复用的外设驱动与示例工程，基于 STC15F2K60S2 最小系
  统板，帮助你快速搭建比赛常用功能。

  ## 项目结构

  - `driver/`：底层驱动代码
    - `led.c/h`：LED、蜂鸣器、电机、继电器控制
    - `seg.c/h`：动态扫描数码管显示
    - `key.c/h`：独立按键扫描与消抖
    - `ds1302.c/h`：DS1302 实时时钟
    - `onewire.c/h`：单总线（如 DS18B20 温度）
    - `iic.c/h`：I2C，总线 ADC/DAC/EEPROM
    - `ultrasound.c/h`：超声波测距模块
    - `uart.c/h`：串口收发、打印调试
    - `init.c/h`：系统与外设基础初始化
  - `user/main.c`：应用示例，集成了时间、温度、AD 值、距离、频率、PWM 等显示逻辑。

  ## 编译与下载

  本仓库仅提供 C 源码，你可以使用任意 IDE 编写：

  - Keil C51：建立工程后，将 `driver/*.c` 与 `user/main.c` 全部加入工程，目标芯片选择 `STC15F2K60S2`，按需配置晶振与下载
  工具。

  生成的 HEX 文件可使用 STC 官方下载工具烧录。

  ## 使用说明

  - 在 user/main.c 中根据题目要求裁剪或扩展功能：
      - 通过 Seg_Show_Mode 切换不同显示模式（时钟、温度、AD、距离、频率、PWM 等）。
      - 使用 Key_Proc()、Led_Proc()、Seg_Proc() 等函数组织主循环逻辑。
  - 建议在此基础上完成蓝桥杯真题：只改动应用层逻辑，尽量复用驱动接口，可大幅缩短调试时间。

  ##源码克隆/下载
  - 若在电脑上安装了 `git` ,即可在 `powershell` 里使用命令 ：
  ```bash
  git clone https://github.com/ThAce-code/LANQIAO_API.git 
  ```
  -若未安装 `git` ,可在 **code** 里选择 **DOWNLOAD ZIP**
  ![100](image.png)
  ## 注意事项

  - 建议保持文件编码为 UTF-8，方便跨平台编辑。
  - 修改驱动前，先阅读对应 .h 文件中的函数说明，确保接口含义与时序满足器件手册要求。